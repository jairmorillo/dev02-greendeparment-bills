<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paids extends Model
{
    //
}
